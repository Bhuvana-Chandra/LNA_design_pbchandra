#created on 12th May 2017 16:30 -- Dhruvin Shah 
## Setup Cadence IC and Spectre Environment
CDSINST=/vlsi/cad/cadence/IC617_ISR23
export CDS_ROOT=$CDSINST/tools/bin
export CDSHOME=$CDSINST
export CDS_HOME=$CDSINST
export PATH=$CDSHOME/tools/mdl/bin:$CDSHOME/tools/dfII/bin:/$CDSHOME/tools/bin:$PATH
export LD_LIBRARY_PATH=$CDSHOME/tools/lib64:$CDSHOME/tools/dfII/lib/:$CDSHOME/tools/inca/lib/64bit:/lib:/usr/lib:/usr/lib64
export MMSIMHOME=/vlsi/cad/cadence/MMSIM151
export MMSIM_PATH=$MMSIMHOME/tools/bin
export SPECTRE_PATH=/vlsi/cad/cadence/SPECTRE171/bin
export PATH=$SPECTRE_PATH:$MMSIM_PATH:$PATH
#export PATH=$MMSIM_PATH:$PATH

#QRC 
export QRC_HOME=/vlsi/cad/cadence/EXT161
export PATH=$PATH:$QRC_HOME/bin

# Comment out if you don't want to over-write your LM_LICENSE_FILE variable.
# However, make sure the required license servers are specified if you're
# commenting the line below.
export LM_LICENSE_FILE=27000@10.107.90.17:27000@10.107.90.16:27000@10.107.90.14:27002@10.107.90.12:27020@10.107.90.16:5280@10.107.90.41
export LM_LICENSE_FILE=$LM_LICENSE_FILE:27020@10.107.90.17:27020@10.107.90.14

# Comment out if using a 32-bit machine or if a 64bit version of any required
# tool is unavailable
export CDS_AUTO_64BIT=ALL

#get rid of annoying os messages
export W3264_NO_HOST_CHECK=1

#solve netlisting issue/view not found
export CDS_Netlisting_Mode=Analog

## Setup Calibre Environment for DRC and LVS
export CALIBRE_HOME=/vlsi/cad/mentor/calibre/aoi_cal_2017.4_35.25
export PATH=$PATH:$CALIBRE_HOME/bin

## Setup Hspice Enviornment for Simulation
export HSP_HOME=/vlsi/cad/synopsys/hspice/vL-2016.06-SP1/hspice
export PATH=$PATH:$HSP_HOME/bin

##PDK ROOT
export PDK_INST='/vlsi/pdk/umc/65/current_1P8M1T0F1U_opt26/G-01-LOGIC_MIXED_MODE65N-LL_LOW_K'
## Consult the documentation in
## /vlsi/pdk/umc/13/G-01-MIXED_MODE_RFCMOS13-1P8M-MMC-FSG-L130E/Designkits/Cadence_IC6/doc/ 


